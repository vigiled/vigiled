package fr.vigiled.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String VIGILED_URL = "http://192.168.4.1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Plein écran — masque barre de statut et navigation
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0d0f14"));

        // Config WebView
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Rester dans la WebView (ne pas ouvrir Chrome)
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(android.webkit.WebView view, int errorCode,
                                         String description, String failingUrl) {
                // Afficher page d'erreur si ESP32 non connecté
                String html = "<html><body style='background:#0d0f14;color:#6b7280;" +
                    "font-family:sans-serif;display:flex;align-items:center;" +
                    "justify-content:center;height:100vh;margin:0;flex-direction:column;gap:16px'>" +
                    "<div style='font-size:48px'>💡</div>" +
                    "<div style='font-size:20px;color:#e8eaf0;font-weight:bold'>VIGILED</div>" +
                    "<div style='font-size:13px;text-align:center;max-width:260px'>" +
                    "Connectez-vous au WiFi<br>" +
                    "<span style='color:#00e5a0;font-weight:bold'>VIGILED</span>" +
                    "<br>puis relancez l'app</div>" +
                    "<div style='font-size:11px;color:#3a4a5a;margin-top:8px'>" +
                    "Mot de passe : 12345678</div>" +
                    "</body></html>";
                view.loadData(html, "text/html", "UTF-8");
            }
        });

        setContentView(webView);
        webView.loadUrl(VIGILED_URL);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Recharger si on revient dans l'app
        if (webView != null) {
            webView.reload();
        }
        // Maintenir le plein écran
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
